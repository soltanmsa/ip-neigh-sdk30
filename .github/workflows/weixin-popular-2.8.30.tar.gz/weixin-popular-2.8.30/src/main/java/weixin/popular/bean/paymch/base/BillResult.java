package weixin.popular.bean.paymch.base;

/**
 * @ProjectName weixin-popular
 * @Author: zeroJun
 * @Date: 2018/7/18 12:13
 * @Description:
 */
public interface BillResult {
    String getData();
}
