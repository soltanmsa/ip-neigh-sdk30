/**
 * 
 */
package weixin.popular.bean.shakearound.device.group.adddevice;

import weixin.popular.bean.BaseResult;

/**
 * 微信摇一摇周边－添加设备到分组－响应参数
 * @author Moyq5
 * @date 2016年7月31日
 */
public class DeviceGroupAddDeviceResult extends BaseResult {

	// private Object data
}
