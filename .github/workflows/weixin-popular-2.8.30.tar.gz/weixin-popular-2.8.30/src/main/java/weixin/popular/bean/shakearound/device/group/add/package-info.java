/**
 * 微信摇一摇周边－新增分组
 * @author Moyq5
 * @date 2016年7月30日
 */
package weixin.popular.bean.shakearound.device.group.add;