/**
 * 微信摇一摇周边－配置设备与页面的关联关系
 * @author Moyq5
 * @date 2016年7月26日
 */
package weixin.popular.bean.shakearound.device.bindpage;