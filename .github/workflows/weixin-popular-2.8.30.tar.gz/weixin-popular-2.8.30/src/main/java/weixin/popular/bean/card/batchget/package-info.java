/**
 * 微信卡券－卡券管理－批量查询卡券列表
 * @author Moyq5
 * @date 2016年7月27日
 */
package weixin.popular.bean.card.batchget;