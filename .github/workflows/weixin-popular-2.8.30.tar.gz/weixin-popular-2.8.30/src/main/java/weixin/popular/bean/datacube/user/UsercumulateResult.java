package weixin.popular.bean.datacube.user;

import java.util.List;

public class UsercumulateResult {

	private List<Usercumulate> list;

	public List<Usercumulate> getList() {
		return list;
	}

	public void setList(List<Usercumulate> list) {
		this.list = list;
	}

}
