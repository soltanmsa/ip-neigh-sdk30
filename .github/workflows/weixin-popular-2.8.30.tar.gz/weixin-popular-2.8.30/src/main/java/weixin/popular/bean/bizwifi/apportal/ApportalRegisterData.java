package weixin.popular.bean.bizwifi.apportal;

/**
 * @ProjectName weixin-popular
 * @Author: zeroJun
 * @Date: 2018/7/24 16:32
 * @Description:
 */
public class ApportalRegisterData {
    private String secretkey;

    public String getSecretkey() {
        return secretkey;
    }

    public void setSecretkey(String secretkey) {
        this.secretkey = secretkey;
    }
}
