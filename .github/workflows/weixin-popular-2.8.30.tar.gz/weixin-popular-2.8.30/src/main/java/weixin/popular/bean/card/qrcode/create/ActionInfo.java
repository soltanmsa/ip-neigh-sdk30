package weixin.popular.bean.card.qrcode.create;

/**
 * 
 * @author Moyq5
 *
 */
public class ActionInfo {
	
	private ActionInfoCard card;

	public ActionInfoCard getCard() {
		return card;
	}

	public void setCard(ActionInfoCard card) {
		this.card = card;
	}
}
