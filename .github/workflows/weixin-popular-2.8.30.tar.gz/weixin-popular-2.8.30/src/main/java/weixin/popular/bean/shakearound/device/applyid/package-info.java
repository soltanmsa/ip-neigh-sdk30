/**
 * 微信摇一摇周边－设备管理－申请设备ID
 * @author Moyq5
 * @date 2016年7月25日
 */
package weixin.popular.bean.shakearound.device.applyid;