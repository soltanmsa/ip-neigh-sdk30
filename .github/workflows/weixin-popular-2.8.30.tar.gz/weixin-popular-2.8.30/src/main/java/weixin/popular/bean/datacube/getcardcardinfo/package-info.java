/**
 * 微信卡券－卡券管理－统计卡券数据－获取免费券数据接口<br>
 * 支持开发者调用该接口拉取免费券（优惠券、团购券、折扣券、礼品券）在固定时间区间内的相关数据。
 * @author Moyq5
 * @date 2016年7月27日
 */
package weixin.popular.bean.datacube.getcardcardinfo;