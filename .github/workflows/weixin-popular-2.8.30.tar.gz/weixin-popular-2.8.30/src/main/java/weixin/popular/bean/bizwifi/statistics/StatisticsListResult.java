package weixin.popular.bean.bizwifi.statistics;

import weixin.popular.bean.shakearound.AbstractResult;

import java.util.List;

/**
 * @ProjectName weixin-popular
 * @Author: zeroJun
 * @Date: 2018/7/24 17:29
 * @Description:
 */
public class StatisticsListResult extends AbstractResult<List<StatisticsListResultData>> {
}
