/**
 * 微信摇一摇周边－摇一摇红包－设置红包活动抽奖开关
 * GET请求
 * @author Moyq5
 * @date 2016年7月30日
 */
package weixin.popular.bean.shakearound.lottery.setlotteryswitch;