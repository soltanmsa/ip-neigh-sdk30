package weixin.popular.bean.comment;

public class Params {

	private Long msg_data_id;

	private Integer index;

	private Long user_comment_id;

	public Long getMsg_data_id() {
		return msg_data_id;
	}

	public void setMsg_data_id(Long msg_data_id) {
		this.msg_data_id = msg_data_id;
	}

	public Integer getIndex() {
		return index;
	}

	public void setIndex(Integer index) {
		this.index = index;
	}

	public Long getUser_comment_id() {
		return user_comment_id;
	}

	public void setUser_comment_id(Long user_comment_id) {
		this.user_comment_id = user_comment_id;
	}

}
