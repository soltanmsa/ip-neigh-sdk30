/**
 * 微信卡券－投放卡券－创建二维码接口
 * @author Moyq5
 * @date 2016年7月27日
 */
package weixin.popular.bean.card.qrcode.create;