package weixin.popular.bean.scan.infolist;

public class VerifiedCateList {
    private String verified_cate_id;
    private String verified_cate_name;

    public String getVerified_cate_id() {
        return verified_cate_id;
    }

    public void setVerified_cate_id(String verified_cate_id) {
        this.verified_cate_id = verified_cate_id;
    }

    public String getVerified_cate_name() {
        return verified_cate_name;
    }

    public void setVerified_cate_name(String verified_cate_name) {
        this.verified_cate_name = verified_cate_name;
    }
}
