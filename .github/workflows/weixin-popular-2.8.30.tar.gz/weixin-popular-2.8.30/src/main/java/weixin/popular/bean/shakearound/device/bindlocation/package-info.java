/**
 * 微信摇一摇周边－设备管理－配置设备与门店的关联关系
 * @author Moyq5
 * @date 2016年7月26日
 */
package weixin.popular.bean.shakearound.device.bindlocation;