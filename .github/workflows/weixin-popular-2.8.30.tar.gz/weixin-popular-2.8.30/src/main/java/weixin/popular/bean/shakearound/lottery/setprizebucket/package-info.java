/**
 * 微信摇一摇周边－摇一摇红包－录入红包信息
 * @author Moyq5
 * @date 2016年7月30日
 */
package weixin.popular.bean.shakearound.lottery.setprizebucket;