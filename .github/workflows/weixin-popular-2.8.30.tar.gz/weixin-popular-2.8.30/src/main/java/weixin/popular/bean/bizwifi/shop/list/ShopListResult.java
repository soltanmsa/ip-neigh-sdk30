package weixin.popular.bean.bizwifi.shop.list;

import weixin.popular.bean.shakearound.AbstractResult;

/**
 * @ProjectName weixin-popular
 * @Author: zeroJun
 * @Date: 2018/7/24 11:35
 * @Description:
 */
public class ShopListResult extends AbstractResult<ShopListResultData> {

}
