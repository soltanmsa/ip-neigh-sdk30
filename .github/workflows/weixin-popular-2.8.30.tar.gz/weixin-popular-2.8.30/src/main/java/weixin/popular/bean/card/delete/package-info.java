/**
 * 微信卡券－卡券管理－删除卡券接口
 * {
 * 	"card_id": "pFS7Fjg8kV1IdDz01r4SQwMkuCKc"
 * }
 * @author Moyq5
 * @date 2016年7月27日
 */
package weixin.popular.bean.card.delete;