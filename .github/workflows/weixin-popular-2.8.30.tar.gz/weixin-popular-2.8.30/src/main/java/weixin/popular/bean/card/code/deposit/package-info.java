/**
 * 微信卡券－卡券投放－导入code接口
 * @author Moyq5
 * @date 2016年7月27日
 */
package weixin.popular.bean.card.code.deposit;