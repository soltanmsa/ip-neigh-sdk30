/**
 * 微信摇一摇周边－编辑分组信息
 * @author Moyq5
 * @date 2016年7月30日
 */
package weixin.popular.bean.shakearound.device.group.update;