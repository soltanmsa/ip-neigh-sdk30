/**
 * 微信卡券－卡券核销－查询Code接口
 * @author Moyq5
 * @date 2016年7月27日
 */
package weixin.popular.bean.card.code.get;