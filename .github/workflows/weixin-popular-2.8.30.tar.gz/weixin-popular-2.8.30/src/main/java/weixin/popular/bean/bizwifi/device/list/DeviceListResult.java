package weixin.popular.bean.bizwifi.device.list;

import weixin.popular.bean.shakearound.AbstractResult;

/**
 * @ProjectName weixin-popular
 * @Author: zeroJun
 * @Date: 2018/7/24 15:52
 * @Description:
 */
public class DeviceListResult extends AbstractResult<DeviceListResultData> {

}
