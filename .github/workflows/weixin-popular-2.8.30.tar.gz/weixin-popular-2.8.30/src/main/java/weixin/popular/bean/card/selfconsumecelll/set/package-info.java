/**
 * 微信卡券－设置自助核销接口
 * @author Moyq5
 * @date 2016年7月27日
 */
package weixin.popular.bean.card.selfconsumecelll.set;