package weixin.popular.bean.open;

import weixin.popular.bean.BaseResult;

public class OpenResult extends BaseResult {

	private String open_appid;

	public String getOpen_appid() {
		return open_appid;
	}

	public void setOpen_appid(String open_appid) {
		this.open_appid = open_appid;
	}

}
