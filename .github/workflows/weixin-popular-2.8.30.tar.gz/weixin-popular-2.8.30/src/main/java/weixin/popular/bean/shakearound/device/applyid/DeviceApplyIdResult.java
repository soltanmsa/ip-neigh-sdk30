package weixin.popular.bean.shakearound.device.applyid;

import weixin.popular.bean.shakearound.AbstractResult;

/**
 * 微信摇一摇周边－设备管理－申请设备ID－响应参数
 * @author Moyq5
 * @date 2016年7月25日
 */
public class DeviceApplyIdResult extends AbstractResult<DeviceApplyIdResultData> {

}
