/**
 * 
 */
package weixin.popular.bean.shakearound.device.group.getlist;

import weixin.popular.bean.shakearound.AbstractResult;

/**
 * 微信摇一摇周边－查询分组列表－响应参数
 * @author Moyq5
 * @date 2016年7月30日
 */
public class DeviceGroupGetListResult extends AbstractResult<DeviceGroupGetListResultData> {

}
