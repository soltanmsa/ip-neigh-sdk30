/**
 * 
 */
package weixin.popular.bean.shakearound.device.group.update;

import weixin.popular.bean.shakearound.device.group.GroupInfo;

/**
 * 微信摇一摇周边－编辑分组信息－请求参数
 * @author Moyq5
 * @date 2016年7月30日
 */
public class DeviceGroupUpdate extends GroupInfo {

}
