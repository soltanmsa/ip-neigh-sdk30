package weixin.popular.bean.datacube.article;

public class Usershare {

	private String ref_date;

	private Integer ref_hour;

	private Integer share_scene;

	private Integer share_count;

	private Integer share_user;

	public String getRef_date() {
		return ref_date;
	}

	public void setRef_date(String ref_date) {
		this.ref_date = ref_date;
	}

	public Integer getRef_hour() {
		return ref_hour;
	}

	public void setRef_hour(Integer ref_hour) {
		this.ref_hour = ref_hour;
	}

	public Integer getShare_scene() {
		return share_scene;
	}

	public void setShare_scene(Integer share_scene) {
		this.share_scene = share_scene;
	}

	public Integer getShare_count() {
		return share_count;
	}

	public void setShare_count(Integer share_count) {
		this.share_count = share_count;
	}

	public Integer getShare_user() {
		return share_user;
	}

	public void setShare_user(Integer share_user) {
		this.share_user = share_user;
	}

}
