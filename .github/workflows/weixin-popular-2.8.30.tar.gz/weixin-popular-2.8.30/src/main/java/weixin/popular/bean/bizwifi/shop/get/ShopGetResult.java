package weixin.popular.bean.bizwifi.shop.get;

import weixin.popular.bean.shakearound.AbstractResult;

/**
 * @ProjectName weixin-popular
 * @Author: zeroJun
 * @Date: 2018/7/24 11:16
 * @Description:
 */
public class ShopGetResult extends AbstractResult<ShopGetResultData> {

}
