package weixin.popular.bean.datacube.article;

import java.util.List;

public class UsershareResult {

	private List<Usershare> list;

	public List<Usershare> getList() {
		return list;
	}

	public void setList(List<Usershare> list) {
		this.list = list;
	}

}
