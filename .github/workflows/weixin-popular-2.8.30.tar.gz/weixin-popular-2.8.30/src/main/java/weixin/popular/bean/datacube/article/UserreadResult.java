package weixin.popular.bean.datacube.article;

import java.util.List;

public class UserreadResult {

	private List<Userread> list;

	public List<Userread> getList() {
		return list;
	}

	public void setList(List<Userread> list) {
		this.list = list;
	}

}
