package weixin.popular;

public interface Version {
	
	String VERSION = "2.8.30";
}
