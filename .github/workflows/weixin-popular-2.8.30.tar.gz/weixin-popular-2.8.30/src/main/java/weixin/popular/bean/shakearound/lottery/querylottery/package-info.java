/**
 * 微信摇一摇周边－摇一摇红包－红包查询接口
 * GET请求
 * @author Moyq5
 * @date 2016年7月30日
 */
package weixin.popular.bean.shakearound.lottery.querylottery;