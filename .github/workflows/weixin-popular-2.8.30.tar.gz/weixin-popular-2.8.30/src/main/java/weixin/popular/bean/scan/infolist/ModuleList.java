package weixin.popular.bean.scan.infolist;

public class ModuleList {
    private String type;
    private String native_show;
    private String anti_fake_url;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNative_show() {
        return native_show;
    }

    public void setNative_show(String native_show) {
        this.native_show = native_show;
    }

    public String getAnti_fake_url() {
        return anti_fake_url;
    }

    public void setAnti_fake_url(String anti_fake_url) {
        this.anti_fake_url = anti_fake_url;
    }
}
