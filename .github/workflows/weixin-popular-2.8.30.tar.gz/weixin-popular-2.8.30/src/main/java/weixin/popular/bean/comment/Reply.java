package weixin.popular.bean.comment;

/**
 * 作者回复
 * 
 * @author LiYi
 *
 */
public class Reply {

	private String content;

	private String create_time;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getCreate_time() {
		return create_time;
	}

	public void setCreate_time(String create_time) {
		this.create_time = create_time;
	}

}
