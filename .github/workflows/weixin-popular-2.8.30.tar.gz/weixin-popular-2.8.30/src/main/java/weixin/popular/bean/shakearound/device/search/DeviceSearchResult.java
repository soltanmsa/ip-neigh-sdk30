/**
 * 
 */
package weixin.popular.bean.shakearound.device.search;

import weixin.popular.bean.shakearound.AbstractResult;

/**
 * 微信摇一摇周边－设备管理－查询设备列表－响应参数
 * @author Moyq5
 * @date 2016年7月26日
 */
public class DeviceSearchResult extends AbstractResult<DeviceSearchResultData> {

}
