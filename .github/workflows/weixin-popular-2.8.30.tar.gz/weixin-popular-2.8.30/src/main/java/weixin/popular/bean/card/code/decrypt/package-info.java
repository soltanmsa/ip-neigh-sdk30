/**
 * 卡券核销－Code解码接口
 * @author Moyq5
 *
 */
package weixin.popular.bean.card.code.decrypt;