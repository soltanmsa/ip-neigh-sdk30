package weixin.popular.bean.card.get;

import weixin.popular.bean.card.DiscountCard;

public class GetDiscountResult extends GetResult<DiscountCard> {

}
