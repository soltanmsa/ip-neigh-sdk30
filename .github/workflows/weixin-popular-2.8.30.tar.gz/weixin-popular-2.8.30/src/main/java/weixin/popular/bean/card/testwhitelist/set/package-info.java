/**
 * 微信卡券－卡券投放－设置测试白名单
 * @author Moyq5
 *
 */
package weixin.popular.bean.card.testwhitelist.set;