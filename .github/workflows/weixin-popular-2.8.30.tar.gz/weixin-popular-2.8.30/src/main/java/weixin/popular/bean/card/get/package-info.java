/**
 * 卡券类－获取卡券详情
 * 各类卡券响应对象：GetResult 、GetCashResult 、GetDiscountResult 、GetGeneralCouponResult、GetGiftResult 、GetGrouponResult ；<br>
 * @author Moyq5
 *
 */
package weixin.popular.bean.card.get;