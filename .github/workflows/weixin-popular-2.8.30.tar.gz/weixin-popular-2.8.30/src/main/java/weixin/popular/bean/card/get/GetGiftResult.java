package weixin.popular.bean.card.get;

import weixin.popular.bean.card.GiftCard;

public class GetGiftResult extends GetResult<GiftCard> {

}
