package weixin.popular.bean.datacube.user;

import java.util.List;

public class UsersummaryResult {

	private List<Usersummary> list;

	public List<Usersummary> getList() {
		return list;
	}

	public void setList(List<Usersummary> list) {
		this.list = list;
	}

}
