package weixin.popular.bean.bizwifi.homepage.get;

import weixin.popular.bean.shakearound.AbstractResult;

/**
 * @ProjectName weixin-popular
 * @Author: zeroJun
 * @Date: 2018/7/24 17:00
 * @Description:
 */
public class HomePageGetResult extends AbstractResult<HomePageGetResultData> {
}
