/**
 * 投放卡券－图文消息群发卡券
 * @author Moyq5
 * @date 2016年7月27日
 */
package weixin.popular.bean.card.mpnews.gethtml;