package weixin.popular.bean.menu;

import weixin.popular.bean.BaseResult;

public class TrymatchResult extends BaseResult{

	private Button[] button;

	public Button[] getButton() {
		return button;
	}

	public void setButton(Button[] button) {
		this.button = button;
	}


}
