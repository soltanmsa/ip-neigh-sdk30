package weixin.popular.bean.bizwifi.openplugin;

/**
 * @ProjectName weixin-popular
 * @Author: zeroJun
 * @Date: 2018/7/24 10:04
 * @Description:
 */
public class OpenPluginToken {
    private String callback_url;

    public String getCallback_url() {
        return callback_url;
    }

    public void setCallback_url(String callback_url) {
        this.callback_url = callback_url;
    }
}
