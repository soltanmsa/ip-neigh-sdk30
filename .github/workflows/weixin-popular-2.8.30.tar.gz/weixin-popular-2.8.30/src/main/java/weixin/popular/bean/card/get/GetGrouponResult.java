package weixin.popular.bean.card.get;

import weixin.popular.bean.card.GrouponCard;

public class GetGrouponResult extends GetResult<GrouponCard> {

}
