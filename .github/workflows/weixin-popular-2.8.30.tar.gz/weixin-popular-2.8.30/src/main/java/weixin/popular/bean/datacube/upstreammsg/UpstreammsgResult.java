package weixin.popular.bean.datacube.upstreammsg;

import java.util.List;

public class UpstreammsgResult {

	private List<Upstreammsg> list;

	public List<Upstreammsg> getList() {
		return list;
	}

	public void setList(List<Upstreammsg> list) {
		this.list = list;
	}

}
