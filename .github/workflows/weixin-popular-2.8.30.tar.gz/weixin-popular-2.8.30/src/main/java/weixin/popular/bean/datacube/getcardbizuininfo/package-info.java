/**
 * 微信卡券－卡券管理－统计卡券数据－拉取卡券概况数据接口
 * @author Moyq5
 * @date 2016年7月27日
 */
package weixin.popular.bean.datacube.getcardbizuininfo;