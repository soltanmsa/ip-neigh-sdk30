
/**
 * 主要放置微信门店相关接口的bean类
 * @author Moyq5
 *
 */
package weixin.popular.bean.poi;