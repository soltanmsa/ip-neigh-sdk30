/**
 * 微信摇一摇周边－添加设备到分组
 * @author Moyq5
 * @date 2016年7月30日
 */
package weixin.popular.bean.shakearound.device.group.adddevice;