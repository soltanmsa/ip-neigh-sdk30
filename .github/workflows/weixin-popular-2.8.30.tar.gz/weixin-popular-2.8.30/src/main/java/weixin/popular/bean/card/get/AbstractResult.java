package weixin.popular.bean.card.get;

import weixin.popular.bean.card.AbstractCard;

public class AbstractResult  extends GetResult<AbstractCard> {

}
