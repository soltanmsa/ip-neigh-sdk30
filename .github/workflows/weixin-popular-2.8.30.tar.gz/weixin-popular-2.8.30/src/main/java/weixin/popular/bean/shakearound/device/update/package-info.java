/**
 * 微信摇一摇周边－设备管理－编辑设备信息
 * @author Moyq5
 * @date 2016年7月26日
 */
package weixin.popular.bean.shakearound.device.update;