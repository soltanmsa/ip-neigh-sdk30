package weixin.popular.bean.bizwifi.openplugin;

import weixin.popular.bean.shakearound.AbstractResult;

/**
 * @ProjectName weixin-popular
 * @Author: zeroJun
 * @Date: 2018/7/24 10:06
 * @Description:
 */
public class OpenPluginTokenResult extends AbstractResult<OpenPluginTokenResultData> {

}
