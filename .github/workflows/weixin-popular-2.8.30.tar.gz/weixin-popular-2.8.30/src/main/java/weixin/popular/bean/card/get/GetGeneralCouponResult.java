package weixin.popular.bean.card.get;

import weixin.popular.bean.card.GeneralCouponCard;

public class GetGeneralCouponResult extends GetResult<GeneralCouponCard> {

}
