/**
 * 微信卡券－设置买单接口
 * @author Moyq5
 * @date 2016年7月27日
 */
package weixin.popular.bean.card.paycell.set;