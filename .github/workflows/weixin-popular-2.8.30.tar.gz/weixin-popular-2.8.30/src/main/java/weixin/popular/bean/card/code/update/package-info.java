/**
 * 微信卡券－卡券管理－更改Code接口
 * @author Moyq5
 *
 */
package weixin.popular.bean.card.code.update;