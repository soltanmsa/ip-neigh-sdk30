package weixin.popular.bean.menu.selfmenu;

import java.util.List;

public class NewsInfo {

	private List<News> list;

	public List<News> getList() {
		return list;
	}

	public void setList(List<News> list) {
		this.list = list;
	}


}
