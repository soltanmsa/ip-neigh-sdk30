package weixin.popular.api;

/**
 * 微信小店
 * @author nobody
 *
 */
public class MerchantAPI extends BaseAPI{

	/**
	 * 这里一片空白，开源贡献动起手来！
	 * 
	 * 参考其它API的开发方式
	 * 
	 */
}
