package weixin.popular.bean.datacube.interfaces;

import java.util.List;

public class InterfacesummaryResult {

	private List<Interfacesummary> list;

	public List<Interfacesummary> getList() {
		return list;
	}

	public void setList(List<Interfacesummary> list) {
		this.list = list;
	}

}
