package weixin.popular.bean.card.code.checkcode;

import weixin.popular.bean.card.code.deposit.CodeDeposit;

/**
 * 投放卡券－核查code接口－请求参数
 * 
 * @author Moyq5
 *
 */
public class CodeCheckCode extends CodeDeposit {

}
