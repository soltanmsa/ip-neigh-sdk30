/**
 * 卡券类相关接口的公共属性对象
 * @author Moyq5
 *
 */
package weixin.popular.bean.card;