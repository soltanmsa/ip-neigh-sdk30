package weixin.popular.bean.datacube.article;

public class Userread {

	private String ref_date;

	private Integer ref_hour;

	private Integer user_source;

	private Integer int_page_read_user;

	private Integer int_page_read_count;

	private Integer ori_page_read_user;

	private Integer ori_page_read_count;

	private Integer share_user;

	private Integer share_count;

	private Integer add_to_fav_user;

	private Integer add_to_fav_count;

	public String getRef_date() {
		return ref_date;
	}

	public void setRef_date(String ref_date) {
		this.ref_date = ref_date;
	}

	public Integer getRef_hour() {
		return ref_hour;
	}

	public void setRef_hour(Integer ref_hour) {
		this.ref_hour = ref_hour;
	}

	public Integer getUser_source() {
		return user_source;
	}

	public void setUser_source(Integer user_source) {
		this.user_source = user_source;
	}

	public Integer getInt_page_read_user() {
		return int_page_read_user;
	}

	public void setInt_page_read_user(Integer int_page_read_user) {
		this.int_page_read_user = int_page_read_user;
	}

	public Integer getInt_page_read_count() {
		return int_page_read_count;
	}

	public void setInt_page_read_count(Integer int_page_read_count) {
		this.int_page_read_count = int_page_read_count;
	}

	public Integer getOri_page_read_user() {
		return ori_page_read_user;
	}

	public void setOri_page_read_user(Integer ori_page_read_user) {
		this.ori_page_read_user = ori_page_read_user;
	}

	public Integer getOri_page_read_count() {
		return ori_page_read_count;
	}

	public void setOri_page_read_count(Integer ori_page_read_count) {
		this.ori_page_read_count = ori_page_read_count;
	}

	public Integer getShare_user() {
		return share_user;
	}

	public void setShare_user(Integer share_user) {
		this.share_user = share_user;
	}

	public Integer getShare_count() {
		return share_count;
	}

	public void setShare_count(Integer share_count) {
		this.share_count = share_count;
	}

	public Integer getAdd_to_fav_user() {
		return add_to_fav_user;
	}

	public void setAdd_to_fav_user(Integer add_to_fav_user) {
		this.add_to_fav_user = add_to_fav_user;
	}

	public Integer getAdd_to_fav_count() {
		return add_to_fav_count;
	}

	public void setAdd_to_fav_count(Integer add_to_fav_count) {
		this.add_to_fav_count = add_to_fav_count;
	}

}
