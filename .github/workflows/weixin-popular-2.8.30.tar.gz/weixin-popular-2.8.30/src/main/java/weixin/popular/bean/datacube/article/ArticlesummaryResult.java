package weixin.popular.bean.datacube.article;

import java.util.List;

public class ArticlesummaryResult {

	private List<Articlesummary> list;

	public List<Articlesummary> getList() {
		return list;
	}

	public void setList(List<Articlesummary> list) {
		this.list = list;
	}

}
