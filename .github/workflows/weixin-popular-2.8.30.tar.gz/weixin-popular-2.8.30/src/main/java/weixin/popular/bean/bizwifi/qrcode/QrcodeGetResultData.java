package weixin.popular.bean.bizwifi.qrcode;

/**
 * @ProjectName weixin-popular
 * @Author: zeroJun
 * @Date: 2018/7/24 16:46
 * @Description:
 */
public class QrcodeGetResultData {
    private String qrcode_url;

    public String getQrcode_url() {
        return qrcode_url;
    }

    public void setQrcode_url(String qrcode_url) {
        this.qrcode_url = qrcode_url;
    }
}
