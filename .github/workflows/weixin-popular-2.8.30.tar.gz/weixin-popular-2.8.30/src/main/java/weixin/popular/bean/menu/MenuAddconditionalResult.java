package weixin.popular.bean.menu;

import weixin.popular.bean.BaseResult;

public class MenuAddconditionalResult extends BaseResult {
	
	private String menuid;

	public String getMenuid() {
		return menuid;
	}

	public void setMenuid(String menuid) {
		this.menuid = menuid;
	}

}