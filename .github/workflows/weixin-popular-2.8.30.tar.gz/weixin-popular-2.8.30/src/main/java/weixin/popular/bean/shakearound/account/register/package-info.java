/**
 * 微信摇一摇周边－申请开通功能
 * @author Moyq5
 * @date 2016年7月25日
 */
package weixin.popular.bean.shakearound.account.register;