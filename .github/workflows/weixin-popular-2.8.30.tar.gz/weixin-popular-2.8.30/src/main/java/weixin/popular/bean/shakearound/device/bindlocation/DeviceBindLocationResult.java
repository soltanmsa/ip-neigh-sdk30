/**
 * 
 */
package weixin.popular.bean.shakearound.device.bindlocation;

import weixin.popular.bean.BaseResult;

/**
 * 微信摇一摇周边－设备管理－配置设备与(或者其它公众号的)门店的关联关系－响应参数
 * @author Moyq5
 * @date 2016年7月26日
 */
public class DeviceBindLocationResult extends BaseResult {

	// private Object data
}
