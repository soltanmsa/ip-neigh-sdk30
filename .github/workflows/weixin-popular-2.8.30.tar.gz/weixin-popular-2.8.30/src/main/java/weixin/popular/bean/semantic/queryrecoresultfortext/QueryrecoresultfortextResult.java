package weixin.popular.bean.semantic.queryrecoresultfortext;

import weixin.popular.bean.BaseResult;

/**
 * @ProjectName weixin-popular
 * @Author: zeroJun
 * @Date: 2018/7/25 10:11
 * @Description:
 */
public class QueryrecoresultfortextResult extends BaseResult {
    private String result;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
