package weixin.popular.bean.datacube.article;

import java.util.List;

public class ArticletotalResult {

	private List<Articletotal> list;

	public List<Articletotal> getList() {
		return list;
	}

	public void setList(List<Articletotal> list) {
		this.list = list;
	}

}
