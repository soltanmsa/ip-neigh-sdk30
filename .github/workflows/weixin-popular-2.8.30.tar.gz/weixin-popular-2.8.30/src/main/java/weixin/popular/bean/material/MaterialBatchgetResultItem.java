package weixin.popular.bean.material;

public class MaterialBatchgetResultItem {

	private String media_id;

	private MaterialBatchgetResultItemContent content;

	private String name;

	private String update_time;
	
	private String url;

	public String getMedia_id() {
		return media_id;
	}

	public void setMedia_id(String media_id) {
		this.media_id = media_id;
	}

	public MaterialBatchgetResultItemContent getContent() {
		return content;
	}

	public void setContent(MaterialBatchgetResultItemContent content) {
		this.content = content;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(String update_time) {
		this.update_time = update_time;
	}
	
	public void setUrl(String url){
		this.url = url;
	}

 	public String getUrl(){
		return url;
	}
}
