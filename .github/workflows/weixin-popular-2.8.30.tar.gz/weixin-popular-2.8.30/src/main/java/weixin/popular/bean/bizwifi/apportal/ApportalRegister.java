package weixin.popular.bean.bizwifi.apportal;

import weixin.popular.bean.bizwifi.base.ShopInfo;

/**
 * @ProjectName weixin-popular
 * @Author: zeroJun
 * @Date: 2018/7/24 15:41
 * @Description:
 */
public class ApportalRegister extends ShopInfo {
    private Boolean reset;

    public Boolean getReset() {
        return reset;
    }

    public void setReset(Boolean reset) {
        this.reset = reset;
    }
}
