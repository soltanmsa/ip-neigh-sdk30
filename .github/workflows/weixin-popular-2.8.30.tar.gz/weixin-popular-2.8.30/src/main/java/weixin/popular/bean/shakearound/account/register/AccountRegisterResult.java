/**
 * 
 */
package weixin.popular.bean.shakearound.account.register;

import weixin.popular.bean.BaseResult;

/**
 * 微信摇一摇周边－申请开通功能－响应参数
 * @author Moyq5
 * @date 2016年7月31日
 */
public class AccountRegisterResult extends BaseResult {

	// private Object data
}
