/**
 * 卡券类－创建卡券数据bean对象，主要类：<br>
 * 创建卡券：CardCreate、CardCreateCash、CardCreateDiscount、CardCreateGeneralCoupon、CardCreateGift、CardCreateGroupon；<br>
 * 设置卡券：CardSet。<br>
 * 其它主要是属性类或者抽象类。
 * @author Moyq5
 *
 */
package weixin.popular.bean.card.create;