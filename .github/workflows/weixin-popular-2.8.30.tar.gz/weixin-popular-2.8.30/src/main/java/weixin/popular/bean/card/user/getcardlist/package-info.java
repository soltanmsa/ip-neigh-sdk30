/**
 * 微信卡券－卡券管理－获取用户已领取卡券接口
 * @author Moyq5
 * @date 2016年7月27日
 */
package weixin.popular.bean.card.user.getcardlist;