package weixin.popular.bean.bizwifi.qrcode;

import weixin.popular.bean.shakearound.AbstractResult;

/**
 * @ProjectName weixin-popular
 * @Author: zeroJun
 * @Date: 2018/7/24 16:46
 * @Description:
 */
public class QrcodeGetResult extends AbstractResult<QrcodeGetResultData> {
}
