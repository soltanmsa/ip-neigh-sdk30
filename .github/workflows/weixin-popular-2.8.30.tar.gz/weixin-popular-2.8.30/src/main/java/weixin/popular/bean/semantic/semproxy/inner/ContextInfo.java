package weixin.popular.bean.semantic.semproxy.inner;

/**
 * @program: weixin-popular
 * @description:
 * @author: 01
 * @create: 2018-08-18 13:33
 **/
public class ContextInfo {
    private String isFinished;
    private String null_times;

    public String getIsFinished() {
        return isFinished;
    }

    public void setIsFinished(String isFinished) {
        this.isFinished = isFinished;
    }

    public String getNull_times() {
        return null_times;
    }

    public void setNull_times(String null_times) {
        this.null_times = null_times;
    }
}
