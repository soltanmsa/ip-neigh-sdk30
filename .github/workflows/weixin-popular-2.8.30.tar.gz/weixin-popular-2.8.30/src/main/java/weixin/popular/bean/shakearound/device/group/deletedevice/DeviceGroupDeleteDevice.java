/**
 * 
 */
package weixin.popular.bean.shakearound.device.group.deletedevice;

import weixin.popular.bean.shakearound.device.group.adddevice.DeviceGroupAddDevice;

/**
 * 微信摇一摇周边－从分组中移除设备－请求参数
 * @author Moyq5
 * @date 2016年7月31日
 */
public class DeviceGroupDeleteDevice extends DeviceGroupAddDevice {

}
