/**
 * 微信卡券－卡券管理－统计卡券数据－拉取会员卡概况数据接口
 * @author Moyq5
 *
 */
package weixin.popular.bean.datacube.getcardmembercardinfo;