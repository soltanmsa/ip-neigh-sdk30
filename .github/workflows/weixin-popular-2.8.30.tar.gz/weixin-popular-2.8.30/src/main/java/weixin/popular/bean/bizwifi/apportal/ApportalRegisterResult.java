package weixin.popular.bean.bizwifi.apportal;

import weixin.popular.bean.shakearound.AbstractResult;

/**
 * @ProjectName weixin-popular
 * @Author: zeroJun
 * @Date: 2018/7/24 15:41
 * @Description:
 */
public class ApportalRegisterResult extends AbstractResult<ApportalRegisterData> {

}
