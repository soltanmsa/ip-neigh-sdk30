package weixin.popular.bean.menu.selfmenu;

import java.util.List;

public class SelfmenuInfo {

	private List<Button> button;

	public List<Button> getButton() {
		return button;
	}

	public void setButton(List<Button> button) {
		this.button = button;
	}


}
