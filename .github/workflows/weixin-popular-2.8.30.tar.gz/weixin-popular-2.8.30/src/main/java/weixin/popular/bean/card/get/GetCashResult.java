package weixin.popular.bean.card.get;

import weixin.popular.bean.card.CashCard;

public class GetCashResult extends GetResult<CashCard> {

}
