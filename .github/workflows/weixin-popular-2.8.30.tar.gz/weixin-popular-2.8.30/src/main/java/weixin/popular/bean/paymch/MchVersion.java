package weixin.popular.bean.paymch;

/**
 * 2.8.12
 * @author LiYi
 *
 */
public class MchVersion {

	private String version;

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

}
